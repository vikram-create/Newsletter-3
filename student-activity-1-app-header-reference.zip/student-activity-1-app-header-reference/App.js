import * as React from 'react';
import { View } from 'react-native';
import SoundButton from './components/SoundButton'
import AppHeader from './components/AppHeader'
import Button2 from './components/Button2'
import Button3 from './components/Button3'
import likeButton from './components/likeButton'
import dislikeButton from './components/dislikeButton'



export default class App extends React.Component {
  render() {
    return (
      <View>
        <AppHeader/>
        <SoundButton />
        <Button2 />
        <Button3 />
        <dislikeButton />
        <likeButton />
      </View>
    );
  }
}

