import firebase from 'firebase';


const firebaseConfig = {
  apiKey: "AIzaSyBNs7Od8PEkXQttj1D8uAqV1gsq9gkjXxg",
  authDomain: "newsletter-95c7b.firebaseapp.com",
  databaseURL: "https://veocity-3592f.firebaseio.com/",
  projectId: "newsletter-95c7b",
  storageBucket: "newsletter-95c7b.appspot.com",
  messagingSenderId: "842700146424",
  appId: "1:842700146424:web:9ab9b79e7a587cf4d11d0d",
  measurementId: "G-FFZDXJ7QLK"
};

export default firebase.database();